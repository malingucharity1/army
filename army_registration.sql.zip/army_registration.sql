-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 16, 2015 at 11:26 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `army_registration`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `contact`
-- 

CREATE TABLE `contact` (
  `id` int(11) NOT NULL auto_increment,
  `fname` varchar(29) NOT NULL,
  `sname` varchar(12) NOT NULL,
  `tel` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `country` varchar(13) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `contact`
-- 

INSERT INTO `contact` (`id`, `fname`, `sname`, `tel`, `email`, `country`) VALUES 
(1, 'carol', 'peter', 78566666, 'charity@yahoo.fr', 'uganda'),
(2, 'chebte', 'patrick', 87766876, 'charity@yahoo.fr', 'uganda'),
(3, 'chebte', 'patrick', 87766876, 'charity@yahoo.fr', 'uganda');

-- --------------------------------------------------------

-- 
-- Table structure for table `recruit`
-- 

CREATE TABLE `recruit` (
  `id` int(11) NOT NULL auto_increment,
  `fn` varchar(13) NOT NULL,
  `sn` varchar(13) NOT NULL,
  `m_status` varchar(10) NOT NULL,
  `ln` varchar(29) NOT NULL,
  `district` varchar(29) NOT NULL,
  `tel` int(10) NOT NULL,
  `par` varchar(12) NOT NULL,
  `loc` varchar(11) NOT NULL,
  `date` varchar(12) NOT NULL,
  `date_b` varchar(31) NOT NULL,
  `gender` text NOT NULL,
  `age` int(4) NOT NULL,
  `ed_l` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `recruit`
-- 

INSERT INTO `recruit` (`id`, `fn`, `sn`, `m_status`, `ln`, `district`, `tel`, `par`, `loc`, `date`, `date_b`, `gender`, `age`, `ed_l`) VALUES 
(1, 'malingu', 'charity', '078566666', 'UCE', 'Kampala', 0, 'rrrrr', 'married', 'rite', 'Year:', 'Year:', 0, '17');

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `user_id` int(5) NOT NULL auto_increment,
  `username` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`user_id`, `username`, `email`, `password`) VALUES 
(14, 'charity', 'charity@yahoo.fr', 'e10adc3949ba59abbe56e057f20f883e'),
(15, 'ricky', 'ricky@gmail.com', '099ebea48ea9666a7da2177267983138');
